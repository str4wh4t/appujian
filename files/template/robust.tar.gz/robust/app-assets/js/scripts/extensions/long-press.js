/*=========================================================================================
	File Name: long-press.js
	Description: jQuery plugin to ease the writing of accented or rare characters.
	----------------------------------------------------------------------------------------
	Item Name: Robust - Responsive Admin Template
	Version: 2.1
	Author: GeeksLabs
	Author URL: http://www.themeforest.net/user/geekslabs
==========================================================================================*/
$(document).ready(function(){

	$('.long-press').first().longPress();

});